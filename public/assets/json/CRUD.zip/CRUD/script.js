function setBlock(id) {
  document.getElementById(id).style.display = "block";
}
function setNone(id) {
  document.getElementById(id).style.display = "none";
}
